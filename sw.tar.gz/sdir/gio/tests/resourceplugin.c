#include <gio/gio.h>

void
g_io_module_load (GIOModule *module)
{
}

void
g_io_module_unload (GIOModule   *module)
{
}

char **
g_io_module_query (void)
{
  return NULL;
}

